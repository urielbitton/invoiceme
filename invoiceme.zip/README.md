InvoiceMe App


ToDos:
- test app


V2 features:
- dynamic scheduled invoices (dates and invoice number need to change automatically every month)
 |- try https://www.npmjs.com/package/pdf-creator-node to create pdfs on nodejs
- allow to customize invoice email messages with variables (Hi {{Name}}, please find your invoice {{number}} attached...)
- allow edit more invoice specific details (business name, address, tax numbers, etc)