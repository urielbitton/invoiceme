import React from 'react'

export default function RecoverEmailHandler({oobCode}) {
  return (
    <div>RecoverEmailHandler</div>
  )
}
