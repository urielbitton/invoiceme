import React from 'react'

export default function ContactEvents() {
  return (
    <div>
      <br/>
      Coming Soon...
    </div>
  )
}
