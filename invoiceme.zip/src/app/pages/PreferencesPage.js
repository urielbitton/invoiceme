import HelmetTitle from "app/components/ui/HelmetTitle"
import React from 'react'

export default function PreferencesPage() {
  return (
    <div>
      <HelmetTitle title="Preferences" />
      PreferencesPage
    </div>
  )
}
